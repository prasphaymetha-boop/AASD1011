package com.sundaysmp.hammer;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Container;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.inventory.view.AnvilView;

import java.util.*;

public class SundayHammer extends JavaPlugin implements Listener {

    private NamespacedKey key;
    private NamespacedKey craftKey;
    private final Set<UUID> working = new HashSet<>();
    private final Set<Material> blacklist = EnumSet.noneOf(Material.class);
    private final Set<GameMode> allowedModes = EnumSet.noneOf(GameMode.class);

    @Override
    public void onEnable() {
        saveDefaultConfig();
        key = new NamespacedKey(this, "hammer3x3");
        loadBlacklist();
        registerCraftRecipe();
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        if (craftKey != null) getServer().removeRecipe(craftKey);
    }

    // สูตรคราฟ: พิกเอ็กซ์ 1 + สมุดเอนชานต์ 1 (ผลลัพธ์จริงถูกแทนที่ใน onCraft)
    private void registerCraftRecipe() {
        craftKey = new NamespacedKey(this, "hammer3x3_craft");
        getServer().removeRecipe(craftKey);
        List<Material> picks = new ArrayList<>();
        for (Material m : Material.values()) {
            if (m.name().endsWith("_PICKAXE") && !m.name().startsWith("LEGACY_")) picks.add(m);
        }
        ShapelessRecipe r = new ShapelessRecipe(craftKey, new ItemStack(Material.NETHERITE_PICKAXE));
        r.addIngredient(new RecipeChoice.MaterialChoice(picks));
        r.addIngredient(new RecipeChoice.MaterialChoice(Material.ENCHANTED_BOOK));
        getServer().addRecipe(r);
    }

    @EventHandler
    public void onCraft(PrepareItemCraftEvent e) {
        if (!(e.getRecipe() instanceof ShapelessRecipe sr) || !sr.getKey().equals(craftKey)) return;
        ItemStack pick = null, book = null;
        int count = 0;
        for (ItemStack it : e.getInventory().getMatrix()) {
            if (it == null || it.getType().isAir()) continue;
            count++;
            if (isPickaxe(it) && pick == null) pick = it;
            else if (it.getType() == Material.ENCHANTED_BOOK && book == null) book = it;
        }
        if (count != 2 || pick == null || book == null || !has(book) || has(pick)) {
            e.getInventory().setResult(null);
            return;
        }
        // clone ของพิกเอ็กซ์จริง: เอนชานต์ ชื่อ ความทนทาน เดิมอยู่ครบ
        ItemStack result = pick.clone();
        applyTag(result);
        e.getInventory().setResult(result);
    }

    private void loadBlacklist() {
        allowedModes.clear();
        for (String g : getConfig().getStringList("gamemodes")) {
            try { allowedModes.add(GameMode.valueOf(g.toUpperCase())); } catch (IllegalArgumentException ignored) {}
        }
        if (allowedModes.isEmpty()) {
            allowedModes.add(GameMode.SURVIVAL);
            allowedModes.add(GameMode.CREATIVE);
            allowedModes.add(GameMode.ADVENTURE);
        }
        blacklist.clear();
        for (String s : getConfig().getStringList("blacklist")) {
            Material m = Material.matchMaterial(s);
            if (m != null) blacklist.add(m);
        }
    }

    private Component text(String legacy) {
        return LegacyComponentSerializer.legacySection().deserialize(legacy)
                .decoration(TextDecoration.ITALIC, false);
    }

    private ItemStack createBook() {
        ItemStack book = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta meta = book.getItemMeta();
        meta.displayName(text(getConfig().getString("book-name", "§bEnchanted Book 3x3")));
        List<Component> lore = new ArrayList<>();
        for (String l : getConfig().getStringList("book-lore")) lore.add(text(l));
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        book.setItemMeta(meta);
        return book;
    }

    private boolean has(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }

    private boolean isPickaxe(ItemStack item) {
        return item != null && item.getType().name().endsWith("_PICKAXE");
    }

    private void applyTag(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        List<Component> lore = meta.hasLore() && meta.lore() != null
                ? new ArrayList<>(meta.lore()) : new ArrayList<>();
        lore.add(text(getConfig().getString("tool-lore", "§d3x3")));
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(true);
        item.setItemMeta(meta);
    }

    // ---------- Drag & drop: หยิบสมุดแล้ววางทับพิกเอ็กซ์ (ใช้ได้ทั้ง Java และ Bedrock) ----------
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDragApply(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack cursor = e.getCursor();
        ItemStack target = e.getCurrentItem();
        if (cursor == null || cursor.getType() != Material.ENCHANTED_BOOK || !has(cursor)) return;
        if (!isPickaxe(target)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != p.getInventory()) return;

        e.setCancelled(true);
        if (has(target)) {
            p.sendMessage(getConfig().getString("messages.already", "already 3x3"));
            return;
        }
        ItemStack newTool = target.clone();
        applyTag(newTool);
        e.setCurrentItem(newTool);

        ItemStack rest = cursor.clone();
        rest.setAmount(rest.getAmount() - 1);
        p.setItemOnCursor(rest.getAmount() <= 0 ? null : rest);
        p.sendMessage(getConfig().getString("messages.applied-book", "§aใส่ 3x3 ให้พิกเอ็กซ์แล้ว"));
    }

    // ---------- Anvil: book + pickaxe ----------
    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        ItemStack a = e.getInventory().getFirstItem();
        ItemStack b = e.getInventory().getSecondItem();
        if (!isPickaxe(a) || b == null || b.getType() != Material.ENCHANTED_BOOK || !has(b)) return;
        if (has(a)) { e.setResult(null); return; } // มี 3x3 อยู่แล้ว

        ItemStack result = a.clone();
        applyTag(result);
        e.setResult(result);
        if (e.getView() instanceof AnvilView view) {
            view.setRepairCost(getConfig().getInt("anvil-cost", 5));
        }
    }

    // ---------- Mining 3x3 ----------
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (working.contains(p.getUniqueId())) return;
        if (!allowedModes.contains(p.getGameMode())) return;
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (!isPickaxe(tool) || !has(tool)) return;
        if (!p.hasPermission("sundayhammer.use")) return;
        if (p.isSneaking() && getConfig().getBoolean("sneak-disables", true)) return;

        Block center = e.getBlock();
        BlockFace face = null;
        RayTraceResult r = p.rayTraceBlocks(7);
        if (r != null && r.getHitBlock() != null && r.getHitBlock().equals(center)) {
            face = r.getHitBlockFace();
        }
        if (face == null) face = p.getFacing().getOppositeFace();

        boolean onlyPick = getConfig().getBoolean("only-pickaxe-blocks", true);
        working.add(p.getUniqueId());
        try {
            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    if (i == 0 && j == 0) continue;
                    Block b;
                    switch (face) {
                        case UP, DOWN -> b = center.getRelative(i, 0, j);
                        case NORTH, SOUTH -> b = center.getRelative(i, j, 0);
                        default -> b = center.getRelative(0, j, i);
                    }
                    ItemStack cur = p.getInventory().getItemInMainHand();
                    if (!isPickaxe(cur) || !has(cur)) return; // พิกเอ็กซ์พังแล้ว
                    Material t = b.getType();
                    if (t.isAir() || b.isLiquid() || blacklist.contains(t)) continue;
                    if (t.getHardness() < 0) continue;
                    if (b.getState() instanceof Container) continue;
                    if (onlyPick && !b.isPreferredTool(cur)) continue;
                    p.breakBlock(b);
                }
            }
        } finally {
            working.remove(p.getUniqueId());
        }
    }

    // ---------- Command ----------
    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("sundayhammer.give")) {
            s.sendMessage(getConfig().getString("messages.no-permission", "no perm"));
            return true;
        }
        if (a.length >= 1 && a[0].equalsIgnoreCase("reload")) {
            reloadConfig(); loadBlacklist();
            s.sendMessage("§aReloaded");
            return true;
        }
        if (a.length >= 1 && a[0].equalsIgnoreCase("apply")) {
            Player t = null;
            if (a.length >= 2) t = getServer().getPlayerExact(a[1]);
            else if (s instanceof Player pl) t = pl;
            if (t == null) {
                s.sendMessage(getConfig().getString("messages.player-not-found", "not found"));
                return true;
            }
            ItemStack held = t.getInventory().getItemInMainHand();
            if (!isPickaxe(held)) {
                s.sendMessage(getConfig().getString("messages.not-pickaxe", "hold a pickaxe"));
                return true;
            }
            if (has(held)) {
                s.sendMessage(getConfig().getString("messages.already", "already 3x3"));
                return true;
            }
            applyTag(held);
            s.sendMessage(getConfig().getString("messages.applied", "applied"));
            return true;
        }
        if (a.length >= 1 && a[0].equalsIgnoreCase("give")) {
            Player target = null;
            if (a.length >= 2) target = getServer().getPlayerExact(a[1]);
            else if (s instanceof Player pl) target = pl;
            if (target == null) {
                s.sendMessage(getConfig().getString("messages.player-not-found", "not found"));
                return true;
            }
            final Player receiver = target;
            for (ItemStack left : receiver.getInventory().addItem(createBook()).values()) {
                receiver.getWorld().dropItemNaturally(receiver.getLocation(), left);
            }
            s.sendMessage(getConfig().getString("messages.given", "given"));
            return true;
        }
        s.sendMessage(getConfig().getString("messages.usage", "/hammer give [player]"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) return List.of("give", "apply", "reload");
        return null;
    }
}
